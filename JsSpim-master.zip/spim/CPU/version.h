#define SPIM_VERSION "Version 9.1.20 of August 29, 2017"
